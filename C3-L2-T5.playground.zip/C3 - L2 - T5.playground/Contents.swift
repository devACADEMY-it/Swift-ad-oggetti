//: # Metodi
//: ### Swift ad oggetti
//: ## Metodi di istanza
//: Enum, Struct e Class
struct Person {
    let name: String
    
    func move() {
        print("La persona si muove")
    }
    
    func hello() {
        let name = "Pippo"
        print("Ciao \(self.name)")
        move()
    }
}

let p1 = Person(name: "Massimo")
p1.hello()
p1.name


enum Planet {
    case mercury
    case mars
    
    func hello() {
        
    }
}

let e1 = Planet.mars
e1.hello()
//: ## Metodi mutating
// Struct

struct Point {
    var x: Double
    var y: Double
    
    mutating func moveBy(delta: Double) {
        x += delta
        y += delta
    }
}

var po1 = Point(x: 30, y: 20)
po1.x
po1.y
po1.moveBy(delta: 100)
po1.x
po1.y
//: ## Metodi di type
struct Math {
    static func sum(n1: Int, n2: Int) -> Int { return 0 }
    static func diff(n1: Int, n2: Int) -> Int { return 0 }
}

Math.diff(n1: 2, n2: 3)
