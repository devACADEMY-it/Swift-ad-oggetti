//: # Computed Property
//: ### Swift ad oggetti
struct Cerchio {
    var raggio: Double
    var diametro: Double {
        set {
            raggio = newValue / 2.0
        }
        get {
            return raggio * 2
        }
    }
    
}

var c1 = Cerchio(raggio: 20)
c1.diametro
c1.raggio

c1.diametro = 30
c1.raggio

c1.raggio = 50
c1.diametro
