//: # Enumeration
//: ## Swift ad oggetti
enum PuntoCardinale {
    case nord
    case sud
    case ovest
    case est
}

let direzione: PuntoCardinale = .ovest
