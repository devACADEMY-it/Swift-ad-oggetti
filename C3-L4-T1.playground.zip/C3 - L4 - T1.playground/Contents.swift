//: # Proprietà
//: ### Swift ad oggetti
/*:
 * Store Property
 * Computed Property
 * Readonly Property
 * Lazy Property
 */
struct Persona {
    let nome: String
}

let p1 = Persona(nome: "Massimo")
let n1 = p1.nome

