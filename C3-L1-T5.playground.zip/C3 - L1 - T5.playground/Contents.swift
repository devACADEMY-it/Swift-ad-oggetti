//: # Raw Value
//: ### Swift ad oggetti
enum Planet: Int {
    case mercurio = 244
    case venere
    case terra
    case marte
}

Planet.venere.rawValue
Planet.marte.rawValue

let v1 = Planet(rawValue: 489)

let v2: Planet = .mercurio

v2.rawValue
