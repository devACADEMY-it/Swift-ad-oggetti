//: # Access Control
//: ### Swift ad oggetti
/*:
 L'_Access Control_ permette di restringere l'accesso a porzioni del nostro codice da parte di altri file del nostro modulo o di altri moduli esterni.
 
Il _Module_ (Modulo) è una singola unità di codice (es. un applicazione o un framework/libreria)
 
 Access Levels
 * `open`: visibile all'esterno del modulo ed ereditabile (solo per le classi)
 * `public`: visibile all'esterno del modulo, ma non ereditabile (per le classi)
 * `internal`: visibile solo all'interno del modulo
 * `fileprivate`: visibile solo nel file corrente
 * `private`: visibile solo all'interno della dichiarazione (struct/class/enum)
*/
public class Shop {
    private func loadData() {
        print("Caricamento prodotti dal database")
    }
    
    public func buy(productId: Int) {
        loadData()
        print("Prodotto acquistato")
    }
}

let s1 = Shop()
s1.buy(productId: 1)
