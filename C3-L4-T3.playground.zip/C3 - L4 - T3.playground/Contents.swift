//: # Readonly Property
//: ### Swift ad oggetti
struct Cerchio {
    var raggio: Double
    
    var diametro: Double {
        set {
            raggio = newValue / 2.0
        }
        get {
            return raggio * 2
        }
    }
    
    var area: Double {
        get {
            return raggio * raggio * Double.pi
        }
    }
}

var c1 = Cerchio(raggio: 40)

c1.area
