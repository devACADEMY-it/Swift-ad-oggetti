//: # Lazy Property
//: ### Swift ad oggetti
class Database {
    var timeout: Int = 0
    
    init() {
        print("Init database")
    }
    
    func loadProduct() {
        print("Caricamento prodotti dal database")
    }
}

class Shop {
    lazy var db: Database = {
        print("lazy database")
        let database = Database()
        database.timeout = 30
        return database
    }()
    
    private func loadData() {
        self.db.loadProduct()
    }
    
    func buy(productId: Int) {
        self.loadData()
    }
}

let shop = Shop()
shop.buy(productId: 34)
shop.buy(productId: 34)
shop.buy(productId: 34)
shop.buy(productId: 34)
