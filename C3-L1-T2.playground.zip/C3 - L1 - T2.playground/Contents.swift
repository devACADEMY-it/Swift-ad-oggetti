//: # Enumeration & Switch
//: ### Swift ad oggetti
enum PuntoCardinale {
    case nord, sud, ovest, est
}

let direzione: PuntoCardinale = .ovest

switch direzione {
case .nord:
    print("nord")
default:
    print("altra direzione")
}
