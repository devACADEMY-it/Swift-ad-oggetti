//: # Associated Values
//: ### Swift ad oggetti
enum NetworkResponse {
    case success(Int, String)
    case failure(String)
}

func networkRequest() -> NetworkResponse {
    return .failure("Assenza di connettività")
}

let risposta = networkRequest()

switch risposta {
case .success:
    print("Chiamata avvenuta con successo")
case .failure(let message):
    print("Chiamata di rete fallita: \(message)")
}
