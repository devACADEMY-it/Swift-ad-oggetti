//: # Classi
//: ### Swift ad oggetti
/*:
 Rispetto alle `struct`:
 - Possono ereditare
 - Reference Type
 */
class Person {
    let name: String
    
    init(name: String) {
        self.name = name
    }
}

let p1 = Person(name: "Massimo")
