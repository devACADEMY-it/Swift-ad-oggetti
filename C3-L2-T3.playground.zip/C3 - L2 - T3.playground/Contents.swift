//: # Struct e initializers
//: ### Swift ad oggetti
/*:
 - _Default_ initializers
 - _Memberwise_ initializers
 - _Custom_ initializers
 */
struct Customer {
    var age: Int
    var name: String
}

let c1 = Customer(age: 10, name: "Marco")

// Custom

struct Product {
    let id: Int
    let name: String
    var price: Double
    
    init(id: Int, name: String) {
        self.id = id
        self.name = name
        self.price = 10.0
    }
    
    init(id: Int, price: Double) {
        self.id = id
        self.price = price
        self.name = "Nuovo prodotto"
    }
}

let p1 = Product(id: 30, name: "macchina")
let p2 = Product(id: 45, price: 3.6)

p1.name
p2.name
