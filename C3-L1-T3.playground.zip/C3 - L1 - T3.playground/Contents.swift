//: # CaseIterable
//: ### Swift ad oggetti
enum Planet: CaseIterable {
    case mercurio
    case venere
    case terra
    case marte
}

Planet.allCases.count

for planet in Planet.allCases {
    print("Pianeta: \(planet)")
}
