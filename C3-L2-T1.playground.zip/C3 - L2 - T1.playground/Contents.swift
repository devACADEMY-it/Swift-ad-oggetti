//: # Struct
//: ### Swift ad oggetti
/*:
 * può avere proprietà
 * può avere metodi
 */
struct Person {
    let name: String
    
    func move(steps: Int) {
        print("La persona si muove di \(steps) passi")
    }
}

let p1 = Person(name: "Massimo")
p1.move(steps: 4)
p1.name

let p2 = Person(name: "Francesca")
p2.move(steps: 5)
p2.name
