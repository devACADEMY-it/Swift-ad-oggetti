//: # Value Type
//: ### Swift ad oggetti
struct Person {
    var name: String
}

var p1 = Person(name: "Massimo")
p1.name
p1.name = "Marco"
p1.name

var p2 = p1

p2.name
p2.name = "Francesca"
p2.name

p1.name

func hello(person: Person) {
    var p3 = person
    p3.name = "Hello \(p3.name)"
    p3.name
}

hello(person: p2)
p2.name
