//: # Struct e proprietà
//: ### Swift ad oggetti
/*:
 - Proprietà `let`
 - Proprietà `var`
 */
struct Customer {
    let name: String = "Massimo"
}

var c1 = Customer()
//c1.name = "Marco"
c1.name
