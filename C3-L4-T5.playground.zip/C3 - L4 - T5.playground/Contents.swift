//: # Property Observers
//: ### Swift ad oggetti
class Person {
    var age: Int = 0
}

class Policeman: Person {
    override var age: Int {
        didSet {
            print("Il poliziotto ha compiuto \(age) anni, prima aveva \(oldValue) anni")
        }
    }
    
    var badgeNumber: Int {
        willSet {
            print("Il numero sta per cambiare in \(newValue) ora è: \(badgeNumber)")
        }
        didSet {
            print("Il numero è cambiato in \(badgeNumber) prima era: \(oldValue)")
        }
    }
    
    init(badgeNumber: Int, age: Int) {
        self.badgeNumber = badgeNumber
        super.init()
        super.age = age
    }
}

let pm1 = Policeman(badgeNumber: 34, age: 38)
pm1.badgeNumber
pm1.badgeNumber = 56
pm1.badgeNumber

pm1.age += 1
