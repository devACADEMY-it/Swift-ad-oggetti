//: # Ereditarietà
//: ### Swift ad oggetti
class Animal {
    var name: String
    
    init(name: String) {
        self.name = name
    }
    
    func move(steps: Int) {
        print("L'animale si muove di \(steps) passi")
    }
}

let a1 = Animal(name: "Triceratopo")
a1.name
a1.move(steps: 3)

class Dog: Animal {
    var nickname: String
    
    init(nickname: String, name: String) {
        self.nickname = nickname
        super.init(name: name)
    }
    
    override func move(steps: Int) {
        print("\(nickname) si muove di \(steps) passi con le sue zampe")
    }
}

let d1 = Dog(nickname: "Rambo", name: "Labrador")
d1.move(steps: 2)
d1.nickname
d1.name
