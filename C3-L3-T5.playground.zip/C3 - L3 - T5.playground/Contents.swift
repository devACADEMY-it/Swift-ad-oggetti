//: # Identity Operator
//: ### Swift ad oggetti
class Product {
    let price: Int
    var quantity: Int
    
    init(price: Int) {
        self.price = price
        self.quantity = 0
    }
}

let p1 = Product(price: 2)
p1.price
p1.quantity

func buy(product: Product, money: Int) {
    let quantity = money / product.price
    print("Quantity: \(quantity)")
    product.quantity = quantity
}

buy(product: p1, money: 10)
p1.quantity

let p2 = p1
p2.quantity = 32
p2.quantity

p1.quantity

if p1 === p2 {
    print("Stessa referenza")
} else {
    print("diversa")
}

var p3 = Product(price: 9)

if p1 === p3 {
    print("p3 Stessa referenza")
} else {
    print("p3 diversa")
}

p3 = p1

if p1 === p3 {
    print("p3 Stessa referenza")
} else {
    print("p3 diversa")
}
